"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var serverless_common_1 = require("@lighthouse/serverless-common");
var fp_1 = require("lodash/fp");
function parseWinTeamMessages(winteamResponse) {
    var messages = fp_1.getOr([], 'Messages', winteamResponse);
    return messages.map(function (message) {
        var _a = message._id, _id = _a === void 0 ? new serverless_common_1.mongo.ObjectId() : _a, Id = message.Id, IsGlobal = message.IsGlobal, Message = message.Message, Response1 = message.Response1, Response2 = message.Response2, Response1Id = message.Response1Id, Response2Id = message.Response2Id, PunchActionID = message.PunchActionID;
        return {
            _id: _id,
            isGlobal: !!IsGlobal,
            message: Message,
            messageId: Id,
            punchActionId: PunchActionID,
            response1: Response1,
            response1Id: Response1Id,
            response2: Response2,
            response2Id: Response2Id,
        };
    });
}
exports.default = parseWinTeamMessages;
//# sourceMappingURL=index.js.map