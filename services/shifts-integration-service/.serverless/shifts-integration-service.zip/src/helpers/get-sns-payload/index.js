"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function getSnsPayload(params) {
    var endpointArn = params.endpointArn, message = params.message, title = params.title, notificationType = params.type;
    return {
        Message: JSON.stringify({
            default: message,
            APNS: JSON.stringify({
                aps: {
                    alert: message,
                    'content-available': 1,
                    sound: 'default',
                },
                notificationType: notificationType,
            }),
            APNS_SANDBOX: JSON.stringify({
                aps: {
                    alert: message,
                    'content-available': 1,
                    sound: 'default',
                },
                notificationType: notificationType,
            }),
            GCM: JSON.stringify({
                data: {
                    data: {
                        notificationType: notificationType,
                    },
                    message: message,
                    title: title,
                },
            }),
        }),
        MessageStructure: 'json',
        TargetArn: endpointArn,
    };
}
exports.default = getSnsPayload;
//# sourceMappingURL=index.js.map