"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OCCURRENCE_STATUS_ACTIVE = 'active';
exports.OCCURRENCE_STATUS_PENDING = 'pending';
exports.OCCURRENCE_STATUS_EXPIRED = 'expired';
exports.OCCURRENCE_STATUS_RESOLVED = 'resolved';
//# sourceMappingURL=constants.js.map