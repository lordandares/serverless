"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function getDynamoDbConfig(region) {
    return region === 'localhost'
        ? {
            endpoint: 'http://localhost:8000',
            httpOptions: {
                timeout: 5000,
            },
            region: process.env.REGION,
        }
        : {};
}
exports.getDynamoDbConfig = getDynamoDbConfig;
//# sourceMappingURL=config.js.map