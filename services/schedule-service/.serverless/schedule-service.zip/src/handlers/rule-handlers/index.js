"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var createRuleHandler_1 = require("./createRuleHandler");
exports.createRule = createRuleHandler_1.createRuleHandler;
var deleteRuleHandler_1 = require("./deleteRuleHandler");
exports.deleteRule = deleteRuleHandler_1.deleteRuleHandler;
//# sourceMappingURL=index.js.map