"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __spreadArrays = (this && this.__spreadArrays) || function () {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
            r[k] = a[j];
    return r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var common_1 = require("@lighthouse/common");
var serverless_common_1 = require("@lighthouse/serverless-common");
var aws_sdk_1 = require("aws-sdk");
var BPromise = require("bluebird");
var lodash_1 = require("lodash");
var moment = require("moment");
var uuid_1 = require("uuid");
var dynamo_1 = require("../repository/dynamo");
var transform_1 = require("../service/lib/transform");
var process_1 = require("process");
var createOccurrences = function (_a) {
    var arn = _a.arn, arnId = _a.arnId, scheduleId = _a.scheduleId;
    return __awaiter(void 0, void 0, void 0, function () {
        var table, dbObject, result, schedule, applicationId, data, endAt, startAt, scheduleAreas, enabled, scheduleLocations, overridingServiceHours, strategy, hasAreas, occurrenceLocations, occurrences;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    table = process.env.TABLE_SCHEDULES;
                    dbObject = dynamo_1.DynamoRepository(table);
                    if (!arn) {
                        throw new serverless_common_1.errors.ApplicationError({
                            message: 'The `arn` is missing',
                        });
                    }
                    if (!arnId) {
                        throw new serverless_common_1.errors.ApplicationError({
                            message: 'The `arnId` is missing',
                        });
                    }
                    if (!scheduleId) {
                        throw new serverless_common_1.errors.ApplicationError({
                            message: 'The schedule `id` of the resource is missing',
                        });
                    }
                    return [4 /*yield*/, dbObject.getBySchedule({
                            groupType: 'schedule',
                            limit: 1,
                            scheduleId: scheduleId,
                        })];
                case 1:
                    result = _b.sent();
                    console.debug('CreateOccurrences: schedule database result', { result: result });
                    if (lodash_1.isEmpty(result)) {
                        throw new serverless_common_1.errors.ApplicationError({
                            data: { scheduleId: scheduleId },
                            message: 'The schedule is missing',
                        });
                    }
                    schedule = lodash_1.first(result);
                    console.debug('CreateOccurrences: schedule document', { schedule: schedule });
                    applicationId = schedule.applicationId, data = schedule.data, endAt = schedule.endAt, startAt = schedule.startAt;
                    scheduleAreas = data.areas, enabled = data.enabled, scheduleLocations = data.locations, overridingServiceHours = data.serviceHours, strategy = data.strategy;
                    if (!enabled) {
                        console.debug('CreateOccurrences: schedule disabled so returning empty array');
                        return [2 /*return*/, []];
                    }
                    hasAreas = !lodash_1.isEmpty(scheduleAreas);
                    occurrenceLocations = hasAreas ? scheduleAreas : scheduleLocations;
                    console.debug('CreateOccurrences: schedule occurrence locations', {
                        occurrenceLocations: occurrenceLocations,
                    });
                    return [4 /*yield*/, BPromise.reduce(occurrenceLocations, function (accum, locationId) { return __awaiter(void 0, void 0, void 0, function () {
                            var end, now, start, isEndInPast, isStartInPast, generatorEnd, generatorStart, pk, sk, location, locationServiceHours, locationTimezone, serviceHours, generator, occurrenceCount, occurrenceLimit, serviceInterval, _a, done, value, interval, intervalType, occurrenceId, createdAt, occurrenceEnd, occurrenceStart, document_1, err_1, occurrence, cwevents, endDate, ruleName, params, cronFormat, rule, data_1;
                            return __generator(this, function (_b) {
                                switch (_b.label) {
                                    case 0:
                                        end = endAt ? moment(endAt).valueOf() : null;
                                        now = moment.utc().valueOf();
                                        start = moment.utc(startAt).valueOf();
                                        isEndInPast = end ? end < now : false;
                                        isStartInPast = start < now;
                                        generatorEnd = end;
                                        generatorStart = isStartInPast ? now : start;
                                        if (isEndInPast) {
                                            console.debug('CreateOccurrences: Schedule endAt is in past', {
                                                end: end,
                                                endAt: endAt,
                                                scheduleId: scheduleId,
                                            });
                                            return [2 /*return*/, accum];
                                        }
                                        pk = applicationId + "-location";
                                        sk = hasAreas
                                            ? lodash_1.first(scheduleLocations)
                                            : locationId;
                                        return [4 /*yield*/, dbObject.get({ pk: pk, sk: sk })];
                                    case 1:
                                        location = _b.sent();
                                        if (!location) {
                                            throw new serverless_common_1.errors.ApplicationError({
                                                data: { applicationId: applicationId, locationId: locationId, scheduleId: scheduleId },
                                                message: 'CreateOccurrenceError: Location not found when generating occurrence',
                                            });
                                        }
                                        locationServiceHours = lodash_1.get(location, 'data.serviceHours');
                                        locationTimezone = lodash_1.get(location, 'data.serviceHours.timezone');
                                        serviceHours = !!overridingServiceHours
                                            ? overridingServiceHours
                                            : locationServiceHours;
                                        generator = common_1.scheduling.scheduleIntervalsGenerator({
                                            end: generatorEnd,
                                            isInitial: true,
                                            serviceHours: serviceHours,
                                            start: generatorStart,
                                            strategy: strategy,
                                        });
                                        occurrenceCount = 0;
                                        occurrenceLimit = 1;
                                        serviceInterval = null;
                                        _b.label = 2;
                                    case 2:
                                        if (!(occurrenceCount !== occurrenceLimit)) return [3 /*break*/, 10];
                                        _a = generator.next(), done = _a.done, value = _a.value;
                                        console.debug('CreateOccurrences: generator next', { done: done, value: value });
                                        /* istanbul ignore next */
                                        if (done) {
                                            return [3 /*break*/, 10];
                                        }
                                        interval = value.interval, intervalType = value.type;
                                        // NOTE: A service interval is a period of time which occurrences can
                                        // occur within. To add further context to the occurrence document we
                                        // store this so we can add as a reference.
                                        if (intervalType === common_1.scheduling.IntervalTypes.Service) {
                                            console.debug('CreateOccurrences: service interval', { interval: interval });
                                            serviceInterval = interval;
                                            return [3 /*break*/, 2];
                                        }
                                        console.debug('CreateOccurrences: occcurence interval', { interval: interval });
                                        occurrenceId = uuid_1.v4();
                                        createdAt = moment
                                            .utc()
                                            .toDate()
                                            .toISOString();
                                        occurrenceEnd = moment
                                            .utc(interval[1])
                                            .toDate()
                                            .toISOString();
                                        occurrenceStart = moment
                                            .utc(interval[0])
                                            .toDate()
                                            .toISOString();
                                        document_1 = {
                                            applicationId: applicationId,
                                            createdAt: createdAt,
                                            createdBy: {
                                                id: arnId,
                                                label: arn,
                                                type: 'system',
                                            },
                                            data: {
                                                occurrenceInterval: interval,
                                                serviceInterval: serviceInterval,
                                                timezone: locationTimezone,
                                            },
                                            endAt: occurrenceEnd,
                                            groupType: 'occurrence',
                                            locationId: locationId,
                                            location_endAt_occurrenceId: locationId + "-" + occurrenceEnd + "-" + occurrenceId,
                                            occurrenceId: occurrenceId,
                                            pk: applicationId + "-occurrence",
                                            scheduleId: scheduleId,
                                            sk: createdAt + "-" + occurrenceId,
                                            startAt: occurrenceStart,
                                            updatedAt: createdAt,
                                            updatedBy: {
                                                id: arnId,
                                                label: arn,
                                                type: 'system',
                                            },
                                        };
                                        _b.label = 3;
                                    case 3:
                                        _b.trys.push([3, 5, , 6]);
                                        return [4 /*yield*/, serverless_common_1.schemas.validate({
                                                data: document_1,
                                                schema: serverless_common_1.schemas.scheduleOccurrenceDocumentSchema,
                                            })];
                                    case 4:
                                        _b.sent();
                                        return [3 /*break*/, 6];
                                    case 5:
                                        err_1 = _b.sent();
                                        throw new serverless_common_1.errors.ApplicationError({
                                            message: "CreateOccurrenceError: " + err_1.message,
                                        });
                                    case 6:
                                        console.debug('CreateOccurrences: document to be created', { document: document_1 });
                                        return [4 /*yield*/, dbObject.put(document_1)];
                                    case 7:
                                        occurrence = _b.sent();
                                        cwevents = new aws_sdk_1.CloudWatchEvents();
                                        endDate = moment(occurrenceEnd);
                                        ruleName = "oee-" + occurrenceId + "-" + endDate.format('YYYY-MM-DD-HHmm');
                                        params = {
                                            Rule: ruleName,
                                            Targets: [
                                                {
                                                    Arn: process_1.env.SCHEDULE_SERVICE_OCCURRENCE_EXPIRED_ARN || '',
                                                    Id: 'createException',
                                                    Input: JSON.stringify({ occurrenceId: occurrenceId }),
                                                },
                                            ],
                                        };
                                        cronFormat = endDate.format('mm') + " " + endDate.format('HH') + " " + endDate.format('DD') + " " + endDate.format('MM') + " ? " + endDate.format('YYYY');
                                        rule = {
                                            Name: ruleName,
                                            ScheduleExpression: "cron(" + cronFormat + ")",
                                            State: 'ENABLED',
                                        };
                                        return [4 /*yield*/, cwevents.putRule(rule).promise()];
                                    case 8:
                                        _b.sent();
                                        return [4 /*yield*/, cwevents.putTargets(params).promise()];
                                    case 9:
                                        data_1 = _b.sent();
                                        console.debug('ClockWatchEvent Created: ', { data: data_1 });
                                        accum.push(occurrence);
                                        occurrenceCount++;
                                        return [3 /*break*/, 2];
                                    case 10:
                                        occurrenceCount = 0;
                                        return [2 /*return*/, accum];
                                }
                            });
                        }); }, [])];
                case 2:
                    occurrences = _b.sent();
                    console.debug('CreateOccurrences: occurrences', { occurrences: occurrences });
                    return [2 /*return*/, occurrences];
            }
        });
    });
};
var createSchedule = function (_a) {
    var applicationId = _a.applicationId, body = _a.body, userId = _a.userId;
    return __awaiter(void 0, void 0, void 0, function () {
        var table, dbObject, SFS, locations, includedLocations, included, data, document, err_2, scheduleId, result, payload;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    table = process.env.TABLE_SCHEDULES;
                    dbObject = dynamo_1.DynamoRepository(table);
                    SFS = new aws_sdk_1.StepFunctions();
                    if (!applicationId) {
                        throw new serverless_common_1.errors.ApplicationError({
                            message: "The `applicationId` is missing from headers",
                        });
                    }
                    if (!userId) {
                        throw new serverless_common_1.errors.ApplicationError({
                            message: "The `userId` is missing from headers",
                        });
                    }
                    if (lodash_1.isEmpty(body)) {
                        throw new serverless_common_1.errors.ValidationError({
                            message: "A schedule body is required",
                        });
                    }
                    console.debug('CreateSchedule: body', { body: body });
                    return [4 /*yield*/, serverless_common_1.schemas.validate({
                            data: body,
                            options: { context: { isNew: true } },
                            schema: serverless_common_1.schemas.schedulePayloadSchema,
                        })];
                case 1:
                    _b.sent();
                    locations = body.locations;
                    return [4 /*yield*/, BPromise.reduce(locations, function (accum, id) { return __awaiter(void 0, void 0, void 0, function () {
                            var location, name;
                            return __generator(this, function (_a) {
                                switch (_a.label) {
                                    case 0: return [4 /*yield*/, getArea({ applicationId: applicationId, locationId: id })];
                                    case 1:
                                        location = _a.sent();
                                        if (!location) {
                                            return [2 /*return*/, accum];
                                        }
                                        name = location.name;
                                        accum[id] = { name: name };
                                        return [2 /*return*/, accum];
                                }
                            });
                        }); }, {})];
                case 2:
                    includedLocations = _b.sent();
                    console.debug('CreateSchedule: included locations', { includedLocations: includedLocations });
                    included = { locations: includedLocations };
                    data = __assign(__assign({}, body), { applicationId: applicationId, included: included, userId: userId });
                    document = transform_1.payloadToScheduleDocument(data);
                    _b.label = 3;
                case 3:
                    _b.trys.push([3, 5, , 6]);
                    return [4 /*yield*/, serverless_common_1.schemas.validate({
                            data: document,
                            options: { context: { isNew: true } },
                            schema: serverless_common_1.schemas.scheduleDocumentSchema,
                        })];
                case 4:
                    _b.sent();
                    return [3 /*break*/, 6];
                case 5:
                    err_2 = _b.sent();
                    throw new serverless_common_1.errors.ApplicationError({ message: err_2.message });
                case 6:
                    scheduleId = document.scheduleId;
                    console.debug('CreateSchedule: document to be created', { document: document });
                    return [4 /*yield*/, dbObject.put(document)];
                case 7:
                    result = _b.sent();
                    console.debug('CreateSchedule: invoking step function', {
                        applicationId: applicationId,
                        locations: locations,
                        scheduleId: scheduleId,
                        stateMachineArn: process.env.CREATE_SCHEDULE_STEP_FUNCTION,
                    });
                    return [4 /*yield*/, SFS.startExecution({
                            input: JSON.stringify({
                                applicationId: applicationId,
                                locations: locations,
                                scheduleId: scheduleId,
                            }),
                            name: applicationId + "-" + scheduleId + "-" + Date.now(),
                            stateMachineArn: process.env.CREATE_SCHEDULE_STEP_FUNCTION,
                        }).promise()];
                case 8:
                    _b.sent();
                    payload = transform_1.documentToSchedulePayload(result);
                    console.debug('CreateSchedule: response payload', { payload: payload });
                    return [2 /*return*/, payload];
            }
        });
    });
};
var deleteOccurrences = function (scheduleId) { return __awaiter(void 0, void 0, void 0, function () {
    var table, dbObject, occurrences, items, results;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                table = process.env.TABLE_SCHEDULES;
                dbObject = dynamo_1.DynamoRepository(table);
                if (!scheduleId) {
                    throw new serverless_common_1.errors.ApplicationError({
                        message: 'The schedule `id` of the resource to delete is missing',
                    });
                }
                return [4 /*yield*/, dbObject.getBySchedule({
                        groupType: 'occurrence',
                        scheduleId: scheduleId,
                    })];
            case 1:
                occurrences = _a.sent();
                items = lodash_1.map(occurrences, function (occurrence) { return ({
                    pk: occurrence.pk,
                    sk: occurrence.sk,
                }); });
                console.debug('DeleteOccurrences: items to be deleted', { items: items });
                return [4 /*yield*/, dbObject.remove(items)];
            case 2:
                results = _a.sent();
                return [2 /*return*/, results];
        }
    });
}); };
function getArea(_a) {
    var applicationId = _a.applicationId, locationId = _a.locationId;
    return __awaiter(this, void 0, void 0, function () {
        var areasCollection, area;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0: return [4 /*yield*/, serverless_common_1.mongo.getCollection('areas')];
                case 1:
                    areasCollection = _b.sent();
                    return [4 /*yield*/, areasCollection.findOne({
                            _id: new serverless_common_1.mongo.ObjectId(lodash_1.toString(locationId)),
                            application: new serverless_common_1.mongo.ObjectId(lodash_1.toString(applicationId)),
                        })];
                case 2:
                    area = _b.sent();
                    console.debug('GetArea: returned area', { applicationId: applicationId, area: area, locationId: locationId });
                    return [2 /*return*/, area];
            }
        });
    });
}
var getSchedule = function (_a) {
    var applicationId = _a.applicationId, scheduleId = _a.scheduleId;
    return __awaiter(void 0, void 0, void 0, function () {
        var table, dbObject, result, document, payload;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    table = process.env.TABLE_SCHEDULES;
                    dbObject = dynamo_1.DynamoRepository(table);
                    if (!applicationId) {
                        throw new serverless_common_1.errors.ApplicationError({
                            message: "The `applicationId` is missing from headers",
                        });
                    }
                    if (!scheduleId) {
                        throw new serverless_common_1.errors.ValidationError({
                            message: "The schedule `id` is required",
                        });
                    }
                    return [4 /*yield*/, dbObject.getBySchedule({
                            groupType: 'schedule',
                            limit: 1,
                            scheduleId: scheduleId,
                        })];
                case 1:
                    result = _b.sent();
                    console.debug('GetSchedule: database result', { result: result });
                    if (lodash_1.isEmpty(result)) {
                        throw new serverless_common_1.errors.ResourceNotFoundError({
                            id: scheduleId,
                            resource: 'Schedule',
                        });
                    }
                    document = lodash_1.first(result);
                    payload = transform_1.documentToSchedulePayload(document);
                    console.debug('GetSchedule: response payload', { payload: payload });
                    return [2 /*return*/, payload];
            }
        });
    });
};
var listSchedules = function (_a) {
    var applicationId = _a.applicationId;
    return __awaiter(void 0, void 0, void 0, function () {
        var table, dbObject, result, payload;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    table = process.env.TABLE_SCHEDULES;
                    dbObject = dynamo_1.DynamoRepository(table);
                    if (!applicationId) {
                        throw new serverless_common_1.errors.ApplicationError({
                            message: "The `applicationId` is missing from headers",
                        });
                    }
                    return [4 /*yield*/, dbObject.listSchedules(applicationId)];
                case 1:
                    result = _b.sent();
                    console.debug('ListSchedules: database result', { result: result });
                    payload = lodash_1.map(result, transform_1.documentToSchedulePayload);
                    console.debug('ListSchedules: response payload', { payload: payload });
                    return [2 /*return*/, payload];
            }
        });
    });
};
var removeSchedule = function (_a) {
    var applicationId = _a.applicationId, scheduleId = _a.scheduleId;
    return __awaiter(void 0, void 0, void 0, function () {
        var table, dbObject, items, itemKeys, schedule, locations;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    table = process.env.TABLE_SCHEDULES;
                    dbObject = dynamo_1.DynamoRepository(table);
                    if (!applicationId) {
                        throw new serverless_common_1.errors.ApplicationError({
                            message: "The `applicationId` is missing from headers",
                        });
                    }
                    if (!scheduleId) {
                        throw new serverless_common_1.errors.ValidationError({
                            message: 'The schedule `id` of the resource to delete is missing',
                        });
                    }
                    return [4 /*yield*/, dbObject.getBySchedule({
                            scheduleId: scheduleId,
                        })];
                case 1:
                    items = _b.sent();
                    console.debug('RemoveSchedule: database results', { results: items });
                    itemKeys = lodash_1.map(items, function (_a) {
                        var pk = _a.pk, sk = _a.sk;
                        return ({ pk: pk, sk: sk });
                    });
                    console.debug('RemoveSchedule: items to be removed', { items: itemKeys });
                    return [4 /*yield*/, dbObject.remove(itemKeys)];
                case 2:
                    _b.sent();
                    schedule = lodash_1.first(lodash_1.filter(items, { groupType: 'schedule' }));
                    locations = schedule.data.locations;
                    console.debug('RemoveSchedule: schedule locations', { locations: locations });
                    return [4 /*yield*/, BPromise.each(locations, function (locationId) { return __awaiter(void 0, void 0, void 0, function () {
                            var locationDocument, schedules, updatedSchedules, updatedLocationDocument;
                            return __generator(this, function (_a) {
                                switch (_a.label) {
                                    case 0: return [4 /*yield*/, dbObject.get({
                                            pk: applicationId + "-location",
                                            sk: locationId,
                                        })];
                                    case 1:
                                        locationDocument = _a.sent();
                                        console.debug('RemoveSchedule: location database result', {
                                            locationDocument: locationDocument,
                                        });
                                        if (!locationDocument) {
                                            console.log('RemoveSchedule: Schedule referenced a missing location', {
                                                locationId: locationId,
                                                scheduleId: scheduleId,
                                            });
                                            return [2 /*return*/];
                                        }
                                        schedules = locationDocument.schedules;
                                        updatedSchedules = lodash_1.without(schedules, scheduleId);
                                        updatedLocationDocument = __assign(__assign({}, locationDocument), { schedules: updatedSchedules });
                                        console.debug('RemoveSchedule: location document update', {
                                            updatedLocationDocument: updatedLocationDocument,
                                        });
                                        return [4 /*yield*/, dbObject.put(updatedLocationDocument)];
                                    case 2:
                                        _a.sent();
                                        return [2 /*return*/];
                                }
                            });
                        }); })];
                case 3:
                    _b.sent();
                    return [2 /*return*/];
            }
        });
    });
};
var updateSchedule = function (_a) {
    var applicationId = _a.applicationId, body = _a.body, scheduleId = _a.scheduleId, userId = _a.userId;
    return __awaiter(void 0, void 0, void 0, function () {
        var table, dbObject, SFS, result, existingDocument, existingDocumentPayload, locations, includedLocations, included, data, document, err_3, updatedDocument, payload;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    table = process.env.TABLE_SCHEDULES;
                    dbObject = dynamo_1.DynamoRepository(table);
                    SFS = new aws_sdk_1.StepFunctions();
                    if (!applicationId) {
                        throw new serverless_common_1.errors.ApplicationError({
                            message: "The `applicationId` is missing from headers",
                        });
                    }
                    if (!userId) {
                        throw new serverless_common_1.errors.ApplicationError({
                            message: "The `userId` is missing from headers",
                        });
                    }
                    if (!scheduleId) {
                        throw new serverless_common_1.errors.ValidationError({
                            message: "The schedule `id` is required",
                        });
                    }
                    if (lodash_1.isEmpty(body)) {
                        throw new serverless_common_1.errors.ValidationError({
                            message: "A schedule body is required",
                        });
                    }
                    console.debug('UpdateSchedule: body', { body: body });
                    return [4 /*yield*/, serverless_common_1.schemas.validate({
                            data: body,
                            options: { context: { isNew: false } },
                            schema: serverless_common_1.schemas.schedulePayloadSchema,
                        })];
                case 1:
                    _b.sent();
                    return [4 /*yield*/, dbObject.getBySchedule({
                            groupType: 'schedule',
                            limit: 1,
                            scheduleId: scheduleId,
                        })];
                case 2:
                    result = _b.sent();
                    console.debug('UpdateSchedule: database result', { result: result });
                    if (lodash_1.isEmpty(result)) {
                        throw new serverless_common_1.errors.ResourceNotFoundError({
                            id: scheduleId,
                            resource: 'Schedule',
                        });
                    }
                    existingDocument = lodash_1.first(result);
                    console.debug('UpdateSchedule: existing document', { existingDocument: existingDocument });
                    existingDocumentPayload = transform_1.documentToSchedulePayload(existingDocument);
                    console.debug('UpdateSchedule: existing document payload', {
                        existingDocumentPayload: existingDocumentPayload,
                    });
                    locations = body.locations;
                    return [4 /*yield*/, BPromise.reduce(locations, function (accum, id) { return __awaiter(void 0, void 0, void 0, function () {
                            var location, name;
                            return __generator(this, function (_a) {
                                switch (_a.label) {
                                    case 0: return [4 /*yield*/, getArea({ applicationId: applicationId, locationId: id })];
                                    case 1:
                                        location = _a.sent();
                                        if (!location) {
                                            return [2 /*return*/, accum];
                                        }
                                        name = location.name;
                                        accum[id] = { name: name };
                                        return [2 /*return*/, accum];
                                }
                            });
                        }); }, {})];
                case 3:
                    includedLocations = _b.sent();
                    console.debug('UpdateSchedule: included locations', { includedLocations: includedLocations });
                    included = { locations: includedLocations };
                    data = __assign(__assign(__assign({}, existingDocumentPayload), body), { 
                        // NOTE: prevent user from overwriting properties
                        applicationId: applicationId, createdAt: existingDocument.createdAt, createdBy: existingDocument.createdBy, id: scheduleId, included: included,
                        userId: userId });
                    document = transform_1.payloadToScheduleDocument(data);
                    console.debug('UpdateSchedule: payload to document', { document: document });
                    _b.label = 4;
                case 4:
                    _b.trys.push([4, 6, , 7]);
                    return [4 /*yield*/, serverless_common_1.schemas.validate({
                            data: document,
                            options: { context: { isNew: false } },
                            schema: serverless_common_1.schemas.scheduleDocumentSchema,
                        })];
                case 5:
                    _b.sent();
                    return [3 /*break*/, 7];
                case 6:
                    err_3 = _b.sent();
                    throw new serverless_common_1.errors.ApplicationError({ message: err_3.message });
                case 7:
                    console.debug('UpdateSchedule: document to be updated', { document: document });
                    return [4 /*yield*/, dbObject.put(document)];
                case 8:
                    updatedDocument = _b.sent();
                    console.debug('UpdateSchedule: invoking step function', {
                        applicationId: applicationId,
                        locations: locations,
                        scheduleId: scheduleId,
                        stateMachineArn: process.env.UPDATE_SCHEDULE_STEP_FUNCTION,
                    });
                    return [4 /*yield*/, SFS.startExecution({
                            input: JSON.stringify({
                                applicationId: applicationId,
                                locations: locations,
                                scheduleId: scheduleId,
                            }),
                            name: applicationId + "-" + scheduleId + "-" + Date.now(),
                            stateMachineArn: process.env.UPDATE_SCHEDULE_STEP_FUNCTION,
                        }).promise()];
                case 9:
                    _b.sent();
                    payload = transform_1.documentToSchedulePayload(updatedDocument);
                    console.debug('UpdateSchedule: response payload', { payload: payload });
                    return [2 /*return*/, payload];
            }
        });
    });
};
var upsertLocation = function (_a) {
    var applicationId = _a.applicationId, arn = _a.arn, arnId = _a.arnId, locationId = _a.locationId, scheduleId = _a.scheduleId;
    return __awaiter(void 0, void 0, void 0, function () {
        var table, dbObject, area, name, serviceHours, existingLocation, actor, now, createdAt, createdBy, schedules, document, err_4, result;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    table = process.env.TABLE_SCHEDULES;
                    dbObject = dynamo_1.DynamoRepository(table);
                    if (!applicationId) {
                        throw new serverless_common_1.errors.ApplicationError({
                            message: 'The `applicationId` is missing',
                        });
                    }
                    if (!arn) {
                        throw new serverless_common_1.errors.ApplicationError({
                            message: 'The `arn` is missing',
                        });
                    }
                    if (!arnId) {
                        throw new serverless_common_1.errors.ApplicationError({
                            message: 'The `arnId` is missing',
                        });
                    }
                    if (!locationId) {
                        throw new serverless_common_1.errors.ApplicationError({
                            message: 'The `locationId` is missing',
                        });
                    }
                    return [4 /*yield*/, getArea({ applicationId: applicationId, locationId: locationId })];
                case 1:
                    area = _b.sent();
                    console.debug('UpsertLocation: area', { area: area });
                    name = area.name, serviceHours = area.serviceHours;
                    return [4 /*yield*/, dbObject.get({
                            pk: applicationId + "-location",
                            sk: locationId,
                        })];
                case 2:
                    existingLocation = _b.sent();
                    console.debug('UpsertLocation: existing location', { existingLocation: existingLocation });
                    actor = { id: arnId, label: arn, type: 'system' };
                    now = moment
                        .utc()
                        .toDate()
                        .toISOString();
                    createdAt = existingLocation ? existingLocation.createdAt : now;
                    createdBy = existingLocation ? existingLocation.createdBy : actor;
                    schedules = existingLocation && scheduleId
                        ? lodash_1.uniq(__spreadArrays(existingLocation.schedules, [scheduleId]))
                        : existingLocation && !scheduleId
                            ? existingLocation.schedules
                            : !existingLocation && scheduleId
                                ? [scheduleId]
                                : [];
                    document = {
                        applicationId: applicationId,
                        createdAt: createdAt,
                        createdBy: createdBy,
                        data: { name: name, serviceHours: serviceHours },
                        groupType: 'location',
                        pk: applicationId + "-location",
                        schedules: schedules,
                        sk: locationId,
                        updatedAt: now,
                        updatedBy: actor,
                    };
                    _b.label = 3;
                case 3:
                    _b.trys.push([3, 5, , 6]);
                    return [4 /*yield*/, serverless_common_1.schemas.validate({
                            data: document,
                            schema: serverless_common_1.schemas.scheduleLocationDocumentSchema,
                        })];
                case 4:
                    _b.sent();
                    return [3 /*break*/, 6];
                case 5:
                    err_4 = _b.sent();
                    throw new serverless_common_1.errors.ApplicationError({ message: err_4.message });
                case 6:
                    console.debug('UpsertLocation: document to be created', { document: document });
                    return [4 /*yield*/, dbObject.put(document)];
                case 7:
                    result = _b.sent();
                    if (!(existingLocation && !lodash_1.isEmpty(existingLocation.schedules))) return [3 /*break*/, 9];
                    return [4 /*yield*/, BPromise.each(existingLocation.schedules, function (id) { return __awaiter(void 0, void 0, void 0, function () {
                            var scheduleResult, existingDocument, nextSchedule;
                            var _a;
                            return __generator(this, function (_b) {
                                switch (_b.label) {
                                    case 0: return [4 /*yield*/, dbObject.getBySchedule({
                                            groupType: 'schedule',
                                            limit: 1,
                                            scheduleId: id,
                                        })];
                                    case 1:
                                        scheduleResult = _b.sent();
                                        console.debug('UpsertLocation: schedule database result', {
                                            scheduleResult: scheduleResult,
                                        });
                                        if (lodash_1.isEmpty(scheduleResult)) {
                                            console.debug('UpsertLocation: Location references a missing schedule', {
                                                locationId: locationId,
                                                scheduleId: id,
                                            });
                                            return [2 /*return*/];
                                        }
                                        existingDocument = lodash_1.first(scheduleResult);
                                        console.debug('UpsertLocation: schedule', { schedule: existingDocument });
                                        nextSchedule = __assign(__assign({}, existingDocument), { data: __assign(__assign({}, existingDocument.data), { included: __assign(__assign({}, existingDocument.data.included), { locations: __assign(__assign({}, existingDocument.data.included.locations), (_a = {}, _a[locationId] = { name: name }, _a)) }) }) });
                                        console.debug('UpsertLocation: document to be updated', {
                                            document: nextSchedule,
                                        });
                                        return [4 /*yield*/, dbObject.put(nextSchedule)];
                                    case 2:
                                        _b.sent();
                                        return [2 /*return*/];
                                }
                            });
                        }); })];
                case 8:
                    _b.sent();
                    _b.label = 9;
                case 9: return [2 /*return*/, result];
            }
        });
    });
};
var ScheduleService = {
    createOccurrences: createOccurrences,
    createSchedule: createSchedule,
    deleteOccurrences: deleteOccurrences,
    getSchedule: getSchedule,
    listSchedules: listSchedules,
    removeSchedule: removeSchedule,
    updateSchedule: updateSchedule,
    upsertLocation: upsertLocation,
};
exports.ScheduleService = ScheduleService;
//# sourceMappingURL=ScheduleService.js.map